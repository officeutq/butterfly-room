#include <bnb/glsl.frag>
#include "bnb_prefabs/hair_strands/shaders/filtered_mask.glsl"

BNB_IN(0)
vec2 var_uv;
BNB_IN(1)
vec2 var_strands_mask_uv;

BNB_DECLARE_SAMPLER_2D(0, 1, tex_strands_mask);

/*
    in hair_strand mode
    strands_hair_colors[0] - small strand, represents hair deep shadows
    strands_hair_colors[1] - average strand, represents hair sub-shadows
    strands_hair_colors[2] - the biggest strand, represents base hair color
    strands_hair_colors[3] - average strand, represents hair sub-highlights
    strands_hair_colors[4] - small strand, represents hair highlights
*/
vec4 get_color(int index)
{
    if (index == 0)
        return strands_hair_color0;
    if (index == 1)
        return strands_hair_color1;
    if (index == 2)
        return strands_hair_color2;
    if (index == 3)
        return strands_hair_color3;
    if (index == 4)
        return strands_hair_color4;
    return vec4(0.);
}

/* returns interpolated color */
vec4 hair_color_linear(float x)
{
    float sample0 = x;

    int sample1 = int(floor(sample0));
    int sample2 = int(ceil(sample0));
    float ratio = fract(sample0);

    vec4 color1 = get_color(sample1);
    vec4 color2 = get_color(sample2);

    return mix(color1, color2, ratio);
}

void main()
{
    float mask = strands_mask(BNB_PASS_SAMPLER_ARGUMENT(tex_strands_mask), var_strands_mask_uv);
    vec4 target_color = hair_color_linear(mask);

    bnb_FragColor = target_color;
}
